import unittest
import os
import json
import csv
import logging
from io import StringIO

from dueno import Dueno
from mascota import Mascota
from consulta import Consulta
from utilidades import buscar_mascota
import persistencia as p

class TestModelos(unittest.TestCase):
    def setUp(self):
        self.dueno = Dueno("Juan Perez", "+56912345678", "Calle Falsa 123", "1-9")
        self.mascota = Mascota("Rex", "Perro", "Labrador", 4, self.dueno)

    def test_dueno_attributes_and_str(self):
        self.assertEqual(self.dueno.nombre, "Juan Perez")
        self.assertEqual(self.dueno.telefono, "+56912345678")
        self.assertEqual(str(self.dueno),
                         "Juan Perez, Tel: +56912345678, Dir: Calle Falsa 123, RUT: 1-9")

    def test_mascota_attributes_and_str(self):
        self.assertEqual(self.mascota.especie, "Perro")
        self.assertEqual(self.mascota.raza, "Labrador")
        self.assertEqual(self.mascota.edad, 4)
        expected = "Rex, Perro, Labrador, 4 años - Dueño: Juan Perez"
        self.assertEqual(str(self.mascota), expected)

    def test_agregar_consulta(self):
        consulta = Consulta("Vacunación al día", self.mascota)
        self.mascota.agregar_consulta(consulta)
        self.assertIn(consulta, self.mascota.consultas)

    def test_consulta_str(self):
        consulta = Consulta("Desparasitación", self.mascota)
        self.assertEqual(str(consulta), "Diagnóstico: Desparasitación")

class TestUtilidades(unittest.TestCase):
    def setUp(self):
        self.dueno = Dueno("Prueba", "+56900000000", "Av. Test 1", "0-0")
        self.mascota = Mascota("Firulais", "Perro", "Labrador", 5, self.dueno)

    def test_buscar_mascota_found(self):
        lista = [self.mascota]
        found = buscar_mascota("Firulais", lista)
        self.assertIsNotNone(found)
        self.assertEqual(found.nombre, "Firulais")

    def test_buscar_mascota_not_found(self):
        lista = []
        self.assertIsNone(buscar_mascota("NoExiste", lista))

class TestPersistenciaCSV(unittest.TestCase):
    def setUp(self):
        try:
            os.remove("mascotas.csv")
        except FileNotFoundError:
            pass
        self.dueno = Dueno("Ana Lopez", "+56987654321", "Av. Siempre Viva 742", "2-7")
        self.mascota = Mascota("Perla", "Gato", "Siames", 2, self.dueno)

    def tearDown(self):
        try:
            os.remove("mascotas.csv")
        except FileNotFoundError:
            pass

    def test_guardar_y_cargar_mascotas_y_duenos(self):
        p.guardar_mascotas_y_duenos_csv([self.mascota], [self.dueno])
        mascotas, duenos = p.cargar_mascotas_y_duenos_csv()
        self.assertEqual(len(mascotas), 1)
        self.assertEqual(len(duenos), 1)
        cargada = mascotas[0]
        self.assertEqual(cargada.nombre, "Perla")
        self.assertEqual(cargada.especie, "Gato")
        self.assertEqual(cargada.dueno.rut, "2-7")

    def test_cargar_sin_archivo_devuelve_listas_vacias(self):
        mascotas, duenos = p.cargar_mascotas_y_duenos_csv()
        self.assertEqual(mascotas, [])
        self.assertEqual(duenos, [])

class TestPersistenciaJSON(unittest.TestCase):
    def setUp(self):
        self.dueno = Dueno("Carlos Diaz", "+56911223344", "Calle Verde 555", "3-5")
        self.mascota = Mascota("Oso", "Perro", "Bulldog", 3, self.dueno)
        try:
            os.remove("consultas.json")
        except FileNotFoundError:
            pass

    def tearDown(self):
        try:
            os.remove("consultas.json")
        except FileNotFoundError:
            pass

    def test_guardar_y_cargar_consultas(self):
        c1 = Consulta("Chequeo General", self.mascota)
        c2 = Consulta("Vacuna", self.mascota)
        p.guardar_consultas_json([c1, c2])
        loaded = p.cargar_consultas_json([self.mascota])
        self.assertEqual(len(loaded), 2)
        self.assertTrue(all(isinstance(c, Consulta) for c in loaded))
        self.assertEqual(loaded[0].diagnostico, "Chequeo General")

    def test_cargar_json_sin_archivo_devuelve_lista_vacia(self):
        loaded = p.cargar_consultas_json([self.mascota])
        self.assertEqual(loaded, [])

class TestExcepciones(unittest.TestCase):
    def setUp(self):
        self.dueno = Dueno("Test", "+56911111111", "Calle Test 123", "9-9")

    def test_mascota_edad_negativa_lanza_excepcion(self):
        with self.assertRaises(ValueError):
            Mascota("Negativo", "Gato", "Común", -2, self.dueno)

class TestLogging(unittest.TestCase):
    def setUp(self):
        self.logger = logging.getLogger('persistencia')
        self.stream = StringIO()
        self.handler = logging.StreamHandler(self.stream)
        self.logger.addHandler(self.handler)
        self.logger.setLevel(logging.INFO)

    def tearDown(self):
        self.logger.removeHandler(self.handler)

    def test_logging_guardar_mascotas_csv(self):
        p.guardar_mascotas_y_duenos_csv([], [])
        self.handler.flush()
        contenido = self.stream.getvalue()
        self.assertIn("Guardando mascotas y dueños en CSV", contenido)

if __name__ == '__main__':
    unittest.main(verbosity=2)
