from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('servicios/', views.services, name='services'),
    path('mascotas/', views.pets, name='pets'),
    path('citas/', views.appointments, name='appointments'),
    path('duenos/', views.owners, name='owners'),
]
