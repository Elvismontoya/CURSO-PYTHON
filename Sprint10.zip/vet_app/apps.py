from django.apps import AppConfig

class VetAppConfig(AppConfig):
    name = 'vet_app'
