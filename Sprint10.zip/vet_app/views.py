from django.shortcuts import render

# Datos de ejemplo (placeholder)
SAMPLE_PETS = [
    {'nombre': 'Firulais', 'especie': 'Perro', 'edad': 3, 'dueno': 'Ana'},
    {'nombre': 'Misu',     'especie': 'Gato',  'edad': 2, 'dueno': 'Luis'},
]
SAMPLE_APPOINTMENTS = [
    {'fecha': '2025-06-20', 'hora': '10:00', 'mascota': 'Firulais', 'servicio': 'Vacunación'},
    {'fecha': '2025-06-22', 'hora': '14:30', 'mascota': 'Misu',     'servicio': 'Consulta General'},
]
SAMPLE_OWNERS = [
    {'nombre': 'Ana',  'telefono': '3001234567', 'email': 'ana@example.com'},
    {'nombre': 'Luis', 'telefono': '3009876543', 'email': 'luis@example.com'},
]

def index(request):
    return render(request, 'vet_app/index.html')

def services(request):
    return render(request, 'vet_app/services.html')

def pets(request):
    return render(request, 'vet_app/pets.html', {'mascotas': SAMPLE_PETS})

def appointments(request):
    return render(request, 'vet_app/appointments.html', {'citas': SAMPLE_APPOINTMENTS})

def owners(request):
    return render(request, 'vet_app/owners.html', {'duenos': SAMPLE_OWNERS})
