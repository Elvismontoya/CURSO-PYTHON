from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import date, datetime
import os

app = Flask(__name__)
app.secret_key = 'clave_secreta_veterinaria'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///veterinaria.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Modelos
class Dueno(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    apellido = db.Column(db.String(100), nullable=False)
    documento = db.Column(db.String(20), unique=True, nullable=False)
    telefono = db.Column(db.String(20), nullable=False)
    direccion = db.Column(db.String(200), nullable=False)
    mascotas = db.relationship('Mascota', backref='dueno', lazy=True)

class Mascota(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    raza = db.Column(db.String(100), nullable=False)
    edad = db.Column(db.Integer, nullable=False)
    tipo_animal = db.Column(db.String(50), nullable=False)
    dueno_id = db.Column(db.Integer, db.ForeignKey('dueno.id'), nullable=False)
    consultas = db.relationship('Consulta', backref='mascota', lazy=True)

class Consulta(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fecha = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    enfermedad = db.Column(db.String(200), nullable=False)
    tratamiento = db.Column(db.Text)
    mascota_id = db.Column(db.Integer, db.ForeignKey('mascota.id'), nullable=False)

# Crear la base de datos
with app.app_context():
    db.create_all()
    
@app.context_processor
def inject_now():
    return {'now': datetime.now()}

# Rutas
@app.route('/')
def index():
    # Obtener las 10 consultas más recientes ordenadas por fecha descendente
    consultas_recientes = Consulta.query.order_by(Consulta.fecha.desc()).limit(10).all()
    
    # Estadísticas para el dashboard
    total_duenos = Dueno.query.count()
    total_mascotas = Mascota.query.count()
    consultas_hoy = Consulta.query.filter(db.func.date(Consulta.fecha) == date.today()).count()
    
    return render_template(
        'index.html',
        consultas_recientes=consultas_recientes,
        total_duenos=total_duenos,
        total_mascotas=total_mascotas,
        consultas_hoy=consultas_hoy
    )

# Dueños
@app.route('/duenos')
def listar_duenos():
    busqueda = request.args.get('busqueda', '')
    if busqueda:
        duenos = Dueno.query.filter(
            (Dueno.nombre.contains(busqueda)) | 
            (Dueno.documento.contains(busqueda))
        ).all()
    else:
        duenos = Dueno.query.all()
    return render_template('duenos/listar.html', duenos=duenos, busqueda=busqueda)

@app.route('/duenos/crear', methods=['GET', 'POST'])
def crear_dueno():
    if request.method == 'POST':
        try:
            dueno = Dueno(
                nombre=request.form['nombre'],
                apellido=request.form['apellido'],
                documento=request.form['documento'],
                telefono=request.form['telefono'],
                direccion=request.form['direccion']
            )
            db.session.add(dueno)
            db.session.commit()
            flash('Dueño creado exitosamente!', 'success')
            return redirect(url_for('listar_duenos'))
        except:
            db.session.rollback()
            flash('Error al crear el dueño. Verifique los datos.', 'danger')
    return render_template('duenos/crear.html')

@app.route('/duenos/editar/<int:id>', methods=['GET', 'POST'])
def editar_dueno(id):
    dueno = Dueno.query.get_or_404(id)
    if request.method == 'POST':
        try:
            dueno.nombre = request.form['nombre']
            dueno.apellido = request.form['apellido']
            dueno.documento = request.form['documento']
            dueno.telefono = request.form['telefono']
            dueno.direccion = request.form['direccion']
            db.session.commit()
            flash('Dueño actualizado exitosamente!', 'success')
            return redirect(url_for('listar_duenos'))
        except:
            db.session.rollback()
            flash('Error al actualizar el dueño.', 'danger')
    return render_template('duenos/editar.html', dueno=dueno)

@app.route('/duenos/eliminar/<int:id>')
def eliminar_dueno(id):
    dueno = Dueno.query.get_or_404(id)
    try:
        db.session.delete(dueno)
        db.session.commit()
        flash('Dueño eliminado exitosamente!', 'success')
    except:
        db.session.rollback()
        flash('Error al eliminar el dueño. Tiene mascotas asociadas.', 'danger')
    return redirect(url_for('listar_duenos'))

# Mascotas
@app.route('/mascotas')
def listar_mascotas():
    mascotas = Mascota.query.all()
    return render_template('mascotas/listar.html', mascotas=mascotas)

@app.route('/mascotas/crear', methods=['GET', 'POST'])
def crear_mascota():
    duenos = Dueno.query.all()
    if request.method == 'POST':
        try:
            mascota = Mascota(
                nombre=request.form['nombre'],
                raza=request.form['raza'],
                edad=int(request.form['edad']),
                tipo_animal=request.form['tipo_animal'],
                dueno_id=int(request.form['dueno_id'])
            )
            db.session.add(mascota)
            db.session.commit()
            flash('Mascota creada exitosamente!', 'success')
            return redirect(url_for('listar_mascotas'))
        except:
            db.session.rollback()
            flash('Error al crear la mascota. Verifique los datos.', 'danger')
    return render_template('mascotas/crear.html', duenos=duenos)

@app.route('/mascotas/editar/<int:id>', methods=['GET', 'POST'])
def editar_mascota(id):
    mascota = Mascota.query.get_or_404(id)
    duenos = Dueno.query.all()
    if request.method == 'POST':
        try:
            mascota.nombre = request.form['nombre']
            mascota.raza = request.form['raza']
            mascota.edad = int(request.form['edad'])
            mascota.tipo_animal = request.form['tipo_animal']
            mascota.dueno_id = int(request.form['dueno_id'])
            db.session.commit()
            flash('Mascota actualizada exitosamente!', 'success')
            return redirect(url_for('listar_mascotas'))
        except:
            db.session.rollback()
            flash('Error al actualizar la mascota.', 'danger')
    return render_template('mascotas/editar.html', mascota=mascota, duenos=duenos)

@app.route('/mascotas/eliminar/<int:id>')
def eliminar_mascota(id):
    mascota = Mascota.query.get_or_404(id)
    try:
        db.session.delete(mascota)
        db.session.commit()
        flash('Mascota eliminada exitosamente!', 'success')
    except:
        db.session.rollback()
        flash('Error al eliminar la mascota. Tiene consultas asociadas.', 'danger')
    return redirect(url_for('listar_mascotas'))

# Consultas
@app.route('/consultas')
def listar_consultas():
    consultas = Consulta.query.order_by(Consulta.fecha.desc()).all()
    return render_template('consultas/listar.html', consultas=consultas)

@app.route('/consultas/crear', methods=['GET', 'POST'])
def crear_consulta():
    mascotas = Mascota.query.all()
    if request.method == 'POST':
        try:
            fecha_str = request.form['fecha']
            fecha = datetime.strptime(fecha_str, '%Y-%m-%dT%H:%M')
            
            consulta = Consulta(
                fecha=fecha,
                enfermedad=request.form['enfermedad'],
                tratamiento=request.form['tratamiento'],
                mascota_id=int(request.form['mascota_id'])
            )
            db.session.add(consulta)
            db.session.commit()
            flash('Consulta creada exitosamente!', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al crear la consulta. Error: {str(e)}', 'danger')
    return render_template('consultas/crear.html', mascotas=mascotas, hoy=datetime.now().strftime('%Y-%m-%dT%H:%M'))

@app.route('/consultas/editar/<int:id>', methods=['GET', 'POST'])
def editar_consulta(id):
    consulta = Consulta.query.get_or_404(id)
    mascotas = Mascota.query.all()
    if request.method == 'POST':
        try:
            fecha_str = request.form['fecha']
            consulta.fecha = datetime.strptime(fecha_str, '%Y-%m-%dT%H:%M')
            consulta.enfermedad = request.form['enfermedad']
            consulta.tratamiento = request.form['tratamiento']
            consulta.mascota_id = int(request.form['mascota_id'])
            db.session.commit()
            flash('Consulta actualizada exitosamente!', 'success')
            return redirect(url_for('listar_consultas'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al actualizar la consulta. Error: {str(e)}', 'danger')
    return render_template('consultas/editar.html', consulta=consulta, mascotas=mascotas)

@app.route('/consultas/eliminar/<int:id>')
def eliminar_consulta(id):
    consulta = Consulta.query.get_or_404(id)
    try:
        db.session.delete(consulta)
        db.session.commit()
        flash('Consulta eliminada exitosamente!', 'success')
    except:
        db.session.rollback()
        flash('Error al eliminar la consulta.', 'danger')
    return redirect(url_for('listar_consultas'))

if __name__ == '__main__':
    app.run(debug=True)